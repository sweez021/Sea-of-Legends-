SEA OF LEGENDS — V0.2
Écran Connexion / Inscription ajouté avant le jeu.
Les comptes sont locaux au navigateur pour la démonstration.
Pour un vrai MMO, la prochaine étape sera un backend d'authentification + base de données.
